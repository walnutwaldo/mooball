#ifndef MOOSBALL_H
#define MOOSBALL_H

#include "bot.h"

void moosball_addbot(Bot *b);
void moosball_play(int argc, char *argv[]);

#endif
